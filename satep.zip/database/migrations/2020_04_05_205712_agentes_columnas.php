<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AgentesColumnas extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        Schema::create('agentesColumnas', function (Blueprint $table) { 
            $table->bigIncrements('id');
            $table->integer("agente_id");
            $table->string("columna");
            $table->string("glosaDesc");
            $table->string("descripcipcionagente");

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
