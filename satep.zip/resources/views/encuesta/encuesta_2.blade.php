@extends('layouts.app')

@section('content')

<h1>Encuesta Agente Ruido</h1>


<style type="text/css">
  .tg  {border-collapse:collapse;border-spacing:0;}
  .tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;}
  .tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;}
  .tg .tg-lboi{border-color:inherit;text-align:left;vertical-align:middle}
  .tg .tg-zkhj{font-weight:bold;background-color:#34cdf9;border-color:inherit;text-align:left;vertical-align:middle}
  </style>
  <table class="tg" style="undefined;table-layout: fixed; width: 348px">
  <colgroup>
  <col style="width: 244px">
  <col style="width: 52px">
  <col style="width: 52px">
  </colgroup>
    <tr>
      <th class="tg-lboi">TRABAJA CON CHORRO DE ARENA</th>
      <th class="tg-lboi"></th>
      <th class="tg-lboi"></th>
    </tr>
    <tr>
      <td class="tg-zkhj" colspan="3">USO DE EQUIPO DE PROTECCIÓN INDIVIDUAL</td>
    </tr>
    <tr>
      <td class="tg-lboi"></td>
      <td class="tg-lboi"></td>
      <td class="tg-lboi"></td>
    </tr>
    <tr>
      <td class="tg-lboi">MASCARARILLA</td>
      <td class="tg-lboi"></td>
      <td class="tg-lboi"></td>
    </tr>
    <tr>
      <td class="tg-lboi">EXISTE PROGRAMA DE MANTENCIÓN</td>
      <td class="tg-lboi"></td>
      <td class="tg-lboi"></td>
    </tr>
    <tr>
      <td class="tg-zkhj" colspan="3">FRECUENCIA DE USO</td>
    </tr>
    <tr>
      <td class="tg-lboi"></td>
      <td class="tg-lboi"></td>
      <td class="tg-lboi"></td>
    </tr>
  </table>
  

   
</div>
<form action="" method="post">


</form>


@endsection