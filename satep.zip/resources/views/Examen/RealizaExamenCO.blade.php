@extends('layouts.app')

@section('content')

@include('prueba.ex_co', ['title' => ''])

@endsection