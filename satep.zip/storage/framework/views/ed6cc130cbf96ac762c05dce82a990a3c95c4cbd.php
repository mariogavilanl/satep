<?php $__env->startSection('content'); ?>

<script>


function verResultado(id){

window.location.href = "/medico/ver-resultado-examen?id="+id;

}

</script>

<div class="card">
<h4>Lista de Examenes realizados, <?php echo e($usuario->name); ?></h4>
</div>

<table class="table table-striped">
    <thead>
        <tr>
            <th>Paciente</th>
            <th>Agente</th>
            <th>Hora</th>
        </tr>
    </thead>

    <body>
        <?php $__currentLoopData = $realizados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr onclick="verResultado(<?php echo e($item->idExamen); ?>)" style="cursor: pointer" >
        <td><?php echo e($item->primerNombre); ?>  <?php echo e($item->segundoNombre); ?> <?php echo e($item->primerApellido); ?> <?php echo e($item->segundoApellido); ?></td>
            <td> <?php echo e($item->glosaAgente); ?> </td>
            <td> <?php echo e($item->fechaExamen); ?> </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
    </body>
</table>


    

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\dev\sys-satep\satep\resources\views/prueba/listaExamenesRealizados.blade.php ENDPATH**/ ?>