<?php $__env->startSection('content'); ?>

<script>
    function reevaluar(id){

        window.location.href = "/reevaluar?id="+id;
    }
</script>

<div class="container-fluid">
    <div class="row">
        <div class="col-sm-12">
            <table class="table table-striped">
                <thead>
                    <tr>
                        
                        <th>Paciente</th>
                        <th>Agente</th>
                        <th>Fecha Evaluación</th>

                    </tr>
                </thead>

                <tbody>

                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr onclick="reevaluar(<?php echo e($item->id); ?>)" style="cursor : pointer">
                            <td> <?php echo e($item->paciente->primerNombre); ?> <?php echo e($item->paciente->segundoNombre); ?> <?php echo e($item->paciente->primerApellido); ?> <?php echo e($item->paciente->segundoApellido); ?> </td>
                            <td> <?php echo e($item->agente->glosaAgente); ?> </td>
                            <td> <?php echo e($item->created_at); ?> </td>
                        </tr>    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    

                </tbody>
            </table>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\dev\sys-satep\satep\resources\views/prueba/reevaluaciones.blade.php ENDPATH**/ ?>