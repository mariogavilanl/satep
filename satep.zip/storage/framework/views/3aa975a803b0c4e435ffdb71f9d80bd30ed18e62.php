<?php $__env->startSection('content'); ?>
<?php ob_start(); ?>
<script>
    function generarPdf(idExamen){

        //conchetumare
        
        //generar-pdf-resultado-examen
        window.location.href = "generar-pdf-resultado-examen?idExamen="+idExamen;

    }

    function back(){

        window.history.back();

    }
</script>
           
            <table class="table table-hover">
             
                <thead>
                    <tr>
                        <th>Fecha Laboratorio</th>
                        <th>Fecha Muestra</th>
                
                        <th>UG/G</th>
                        <th>Estado</th>
                
                       
                    </tr>
                    

                </thead>
                
                <tbody>
                    
                    <tr>
                        <tr>
                            <td><?php echo e(Carbon\Carbon::parse($examen->as_FECHALAB1)->format('d/m/Y')); ?></td>
                            <td><?php echo e(Carbon\Carbon::parse($examen->as_FECHAMUESTRA)->format('d/m/Y')); ?></td>
                            <td><?php echo e($examen->as_UG_G); ?></td>
                            <td><?php echo e($examen->as_estado); ?></td>
                          
                        </tr>
                    </tr>
                </tbody>
            </table>
            <br>
            
      
            <button type="" class="btn btn-success" onclick="generarPdf(<?php echo e($examen->idExamen); ?>)" > <span class="fa fa-download" > </span>Descargar archivo PDF </button>
            
            <p>

            </p>
           </div>

           
            <button class="btn btn-primary" onclick="back()" > <span class="fa fa-arrow-left" ></span>  volver  </button>
           
            
       
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\dev\sys-satep\satep\resources\views/doctor/verResultadosExamen.blade.php ENDPATH**/ ?>