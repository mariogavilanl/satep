<?php $__env->startSection('content'); ?>

<style>
    .tdBold{
        font-weight: 700;
    }
</style>

<script>
    function aprobarExamen(){
        
        $.ajax(
        {
            url : "/medico/apruebaExamen?comentario="+$("#doctorObservacion").val(),
            dataType: 'json',           
            type : "get",
            success : function(r){
                console.log("--"+r);
               if (r == "ok") {
                   alert("se ha aprobado el examen");
                   //window.location.replace("/medico");
               }
            },
            complete : function(){
                alert("se ha aprobado el examen");
                //window.location.replace("/medico");
            } 
        });
    }



    function rechazarExamen(){
        
        $.ajax(
        {
            url : "/medico/rechazaExamen?comentario="+$("#doctorObservacion").val(),
            dataType: 'json',           
            type : "get",
            success : function(r){
                console.log("--"+r);
               if (r == "ok") {
                   alert("se ha rechazado el examen");
                   //window.location.replace("/medico");
               }
            },
            complete : function(){
                alert("se ha rechazado el examen");
                //window.location.replace("/medico");
            } 
        });
    }    

</script>


<table class="table table-active">
<tr>

    <td class="tdBold"> 
        Nombre
    </td>
    <td>
     
        <?php echo e($data->paciente->primerNombre); ?> <?php echo e($data->paciente->segundoNombre); ?> <?php echo e($data->paciente->primerApellido); ?> <?php echo e($data->paciente->segundoApellido); ?>

    </td>
    <td class="tdBold"> 
        Fecha de Nacimiento
    </td>
    <td>
        <?php echo e($data->paciente->fechaNacimiento); ?> 
    </td>

    <td class="tdBold"> 
        Edad
    </td>
    <td>
        <?php echo e(Carbon\Carbon::parse($data->paciente->fechaNacimiento)->age); ?>

    </td>
    <td class="tdBold"> 
        Sexo
    </td>
    <td>
        <?php echo e(($data->paciente->sexo == "F" ? "Femenino" : "Mascúlino")); ?> 
    </td>


</tr>

<tr>
    <td class="tdBold"> 
        Rut
    </td>
    <td>
        <?php echo e($data->paciente->rut); ?> 
    </td>
    <td class="tdBold"> 
        Gerencia
    </td>
    <td>
        <?php echo e($data->paciente->gerencia); ?> 
    </td>

    <td class="tdBold"> 
        Cargo
    </td>
    <td>
        <?php echo e($data->paciente->cargo); ?>

    </td>
    <td class="tdBold"> 
        
    </td>
    <td>
        
    </td>      
    
</tr>


</table>


<div class="accordion" id="accordionExample">
   
<?php echo $__env->make('doctor.resultadosAgentes.agente_'.$data->agente->id, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('doctor.resultadosEncuesta.encuesta_agente_'.$data->agente->id, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
</div> 

<div class="container">
    
<div class="row">

    <h5>Observacion Médico</h5>
    <div class="col-12">

    <textarea class="form-control" id="doctorObservacion"></textarea>
    <button class="btn btn-primary" onclick="aprobarExamen()">Guardar</button>
    <button class="btn btn-danger"  onclick="rechazarExamen()">Rechazar</button>


    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\dev\sys-satep\satep\resources\views/doctor/resultados.blade.php ENDPATH**/ ?>