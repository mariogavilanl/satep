<?php $__env->startSection('content'); ?>


<?php switch(($examens->agentes_id == null ? 17 : $examens->agentes_id )):
        case (1): ?>
           
            <?php echo $__env->make('prueba.ex_vigilante_privado', ['title' => ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>

        <?php case (2): ?>

            <?php echo $__env->make('prueba.ex_ruido', ['title' => ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>
        <?php case (6): ?>

            <?php echo $__env->make('prueba.ex_aa', ['title' => ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>

        <?php case (9): ?>

            <?php echo $__env->make('prueba.ex_af', ['title' => ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>

        <?php case (12): ?>

            <?php echo $__env->make('prueba.ex_ag', ['title' => ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?> 
            
        <?php case (18): ?>

            <?php echo $__env->make('prueba.ex_arsenico', ['title' => ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?> 

        <?php case (5): ?>

            <?php echo $__env->make('prueba.ex_citoestaticos', ['title' => ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?> 

        <?php case (4): ?>

            <?php echo $__env->make('prueba.ex_formald', ['title' => ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?> 

        <?php case (18): ?>

            <?php echo $__env->make('prueba.ex_oe', ['title' => ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?> 

        <?php case (16): ?>

            <?php echo $__env->make('prueba.ex_oel', ['title' => ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?> 
            
        <?php case (15): ?>

            <?php echo $__env->make('prueba.ex_oep', ['title' => ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?> 

        <?php case (14): ?>

            <?php echo $__env->make('prueba.ex_osc', ['title' => ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?> 

        <?php case (8): ?>

            <?php echo $__env->make('prueba.ex_plomo', ['title' => ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?> 

        <?php case (10): ?>

            <?php echo $__env->make('prueba.ex_rad1', ['title' => ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?> 
        <?php case (11): ?>

            <?php echo $__env->make('prueba.ex_rad2y3', ['title' => ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?> 

        <?php case (7): ?>

            <?php echo $__env->make('prueba.ex_so2', ['title' => ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>
            
        <?php case (3): ?>

            <?php echo $__env->make('prueba.ex_silice', ['title' => ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?> 

            <?php case (13): ?>

            <?php echo $__env->make('prueba.ex_ec', ['title' => ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?> 

            
        <?php default: ?>

            <?php echo $__env->make('prueba.ex_co', ['title' => ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>
            
    <?php endswitch; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\dev\sys-satep\satep\resources\views/Examen/RealizaExamen.blade.php ENDPATH**/ ?>