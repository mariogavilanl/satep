<?php $__env->startSection('content'); ?>

<script>
    $(document).ready(function(){
        $("#tabla").DataTable({
          "pageLength": 100
        });
    });

    

    function cargaExamen(id, nombre, apellido){
      window.location.href = 'realiza-examen?idCarga='+id;
    }
    function cargaCO(id, nombre, apellido){
      window.location.href = 'realiza-examen-co?idCarga='+id;
    }


</script>   


<style>
  .button {
    
    font-size: 0.7rem;
  }
</style>

<div id="modal-pico" class="modal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-xl" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">titulo</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <p> <span id="nombre" > </span> </p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary">Save changes</button>
        </div>
      </div>
    </div>
  </div>


  <table id="tabla" class="dataTable display no-footer table-hover table-striped" style="font-size: 0.76rem">
    <thead>
        <tr>
            <th>id carga</th>
            <th>Numero Sap</th>
            <th>Nombre</th>
            <th>Apellido</th>           
            <th>Cargo</th>
            <th>Gerencia</th>   
            
            <th>Nombre Agente</th>  
            <th>Acciones</th>          
        </tr>
    </thead>
    <tbody>

    <?php $__currentLoopData = $pico; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($d->realizado == 0 ||  $d->realizadoco == 0): ?>
    <tr class="">
        <td> <?php echo e($d->id); ?></td>
        <td> <?php echo e($d->nroSap); ?></td>
        <td> <?php echo e($d->primerNombre); ?> <?php echo e($d->segundoNombre); ?></td>
        <td> <?php echo e($d->primerApellido); ?></td>
        <td> <?php echo e($d->cargo); ?></td>
        <td> <?php echo e($d->gerencia); ?></td>
         
        <td> <?php echo e($d->glosaAgente); ?></td>       
        <td>

          
          <?php if($d->semestre == 1 && Carbon\Carbon::parse($d->fechaCarga)->year == $fechaactual->year && Carbon\Carbon::parse($d->fechaCarga)->month <= 7 ): ?>
                       
                        <?php if($d->realizado == 0): ?>
                          <button class="btn btn-primary"  onclick="cargaExamen(<?php echo e($d->id); ?>, '<?php echo e($d->primerNombre); ?>','<?php echo e($d->primerApellido); ?>'  )">Examen</button>                    
                        <?php endif; ?>

                        <?php if($d->realizadoco == 0): ?>
                          <button class="btn btn-dark" onclick="cargaCO(<?php echo e($d->id); ?>)">Examen Base</button>                    
                        <?php endif; ?>

                        <?php if($d->agentes_id == 2 || $d->agentes_id == 3 || $d->agentes_id == 6 || $d->agentes_id == 7 || $d->agentes_id == 5 || $d->agentes_id == 4 || $d->agentes_id == 18 ): ?>
                          
                        <?php if($d->encuesta == 0): ?>
                          <a href="/encuesta/?idencuesta=<?php echo e($d->agentes_id); ?>&idcarga=<?php echo e($d->id); ?>&idsap=<?php echo e($d->nroSap); ?>">
                            <button class="btn btn-success">Encuesta</button>
                          </a>
                        <?php endif; ?>
                         
                                            
                      <?php endif; ?>

          <?php endif; ?>

          <?php if($d->semestre == 2 && Carbon\Carbon::parse($d->fechaCarga)->year == $fechaactual->year && $fechaactual->month > 7): ?>
              <?php if($d->realizado == 0): ?>
              <button class="btn btn-primary"  onclick="cargaExamen(<?php echo e($d->id); ?>, '<?php echo e($d->primerNombre); ?>','<?php echo e($d->primerApellido); ?>'  )">Examen</button>                    
            <?php endif; ?>
            <?php if($d->realizadoco == 0): ?>
              <button class="btn btn-dark" onclick="cargaCO(<?php echo e($d->id); ?>)">Examen Base</button>                    
            <?php endif; ?>
            <?php if($d->agentes_id == 2 || $d->agentes_id == 3 || $d->agentes_id == 6 || $d->agentes_id == 7 || $d->agentes_id == 5 || $d->agentes_id == 4 || $d->agentes_id == 18 ): ?>
             

                          
              <?php if($d->encuesta == 0): ?>
              <a href="/encuesta/?idencuesta=<?php echo e($d->agentes_id); ?>&idcarga=<?php echo e($d->id); ?>&idsap=<?php echo e($d->nroSap); ?>">
                <button class="btn btn-success">Encuesta</button>
              </a>
            <?php endif; ?>            
                
          <?php endif; ?>
          <?php endif; ?>

          <?php if($d->semestre == 3 && Carbon\Carbon::parse($d->fechaCarga)->year == $fechaactual->year && $fechaactual->month <= 4): ?>
              <?php if($d->realizado == 0): ?>
              <button class="btn btn-primary"  onclick="cargaExamen(<?php echo e($d->id); ?>, '<?php echo e($d->primerNombre); ?>','<?php echo e($d->primerApellido); ?>'  )">Examen</button>                    
            <?php endif; ?>
            <?php if($d->realizadoco == 0): ?>
              <button class="btn btn-dark" onclick="cargaCO(<?php echo e($d->id); ?>)">Examen Base</button>                    
            <?php endif; ?>
            
            <?php if($d->agentes_id == 2 || $d->agentes_id == 3 || $d->agentes_id == 6 || $d->agentes_id == 7 || $d->agentes_id == 5 || $d->agentes_id == 4 || $d->agentes_id == 18 ): ?>
             
            <?php if($d->encuesta == 0): ?>
              <a href="/encuesta/?idencuesta=<?php echo e($d->agentes_id); ?>&idcarga=<?php echo e($d->id); ?>&idsap=<?php echo e($d->nroSap); ?>">
                <button class="btn btn-success">Encuesta</button>
              </a>
            <?php endif; ?>    
                                 
          <?php endif; ?>
          <?php endif; ?>

          <?php if($d->semestre == 4 && Carbon\Carbon::parse($d->fechaCarga)->year == $fechaactual->year && $fechaactual->month > 4 && $fechaactual->month <= 8): ?>
              <?php if($d->realizado == 0): ?>
              <button class="btn btn-primary"  onclick="cargaExamen(<?php echo e($d->id); ?>, '<?php echo e($d->primerNombre); ?>','<?php echo e($d->primerApellido); ?>'  )">Exam</button>                    
            <?php endif; ?>
            <?php if($d->realizadoco == 0): ?>
              <button class="btn btn-dark" onclick="cargaCO(<?php echo e($d->id); ?>)">Examen Base</button>                    
            <?php endif; ?>

            <?php if($d->agentes_id == 2 || $d->agentes_id == 3 || $d->agentes_id == 6 || $d->agentes_id == 7 || $d->agentes_id == 5 || $d->agentes_id == 4 || $d->agentes_id == 18 ): ?>
             
            <?php if($d->encuesta == 0): ?>
              <a href="/encuesta/?idencuesta=<?php echo e($d->agentes_id); ?>&idcarga=<?php echo e($d->id); ?>&idsap=<?php echo e($d->nroSap); ?>">
                <button class="btn btn-success">Encuesta</button>
              </a>
            <?php endif; ?>    
                                 
          <?php endif; ?>
          <?php endif; ?>

          <?php if($d->semestre == 5 && Carbon\Carbon::parse($d->fechaCarga)->year == $fechaactual->year && Carbon\Carbon::parse($d->fechaCarga)->month > 8 && $fechaactual->month <= 12): ?>
            <?php if($d->realizado == 0): ?>
              <button class="btn btn-primary"  onclick="cargaExamen(<?php echo e($d->id); ?>, '<?php echo e($d->primerNombre); ?>','<?php echo e($d->primerApellido); ?>'  )">Exam</button>                    
            <?php endif; ?>
            <?php if($d->realizadoco == 0): ?>
              <button class="btn btn-dark" onclick="cargaCO(<?php echo e($d->id); ?>)">Examen Base</button>                    
            <?php endif; ?>
            <?php if($d->agentes_id == 2 || $d->agentes_id == 3 || $d->agentes_id == 6 || $d->agentes_id == 7 || $d->agentes_id == 5 || $d->agentes_id == 4 || $d->agentes_id == 18 ): ?>
             
            <?php if($d->encuesta == 0): ?>
            <a href="/encuesta/?idencuesta=<?php echo e($d->agentes_id); ?>&idcarga=<?php echo e($d->id); ?>&idsap=<?php echo e($d->nroSap); ?>">
              <button class="btn btn-success">Encuesta</button>
            </a>
          <?php endif; ?>    
                                 
          <?php endif; ?>
          <?php endif; ?>          

          <?php if($d->semestre == 6): ?>
              <?php if($d->realizado == 0): ?>
              <button class="btn btn-primary"  onclick="cargaExamen(<?php echo e($d->id); ?>, '<?php echo e($d->primerNombre); ?>','<?php echo e($d->primerApellido); ?>'  )">Exam</button>                    
            <?php endif; ?>
            <?php if($d->realizadoco == 0): ?>
              <button class="btn btn-dark" onclick="cargaCO(<?php echo e($d->id); ?>)">Examen Base</button>                    
            <?php endif; ?>
            <?php if($d->agentes_id == 2 || $d->agentes_id == 3 || $d->agentes_id == 6 || $d->agentes_id == 7 || $d->agentes_id == 5 || $d->agentes_id == 4 || $d->agentes_id == 18 ): ?>
             
            <?php if($d->encuesta == 0): ?>
              <a href="/encuesta/?idencuesta=<?php echo e($d->agentes_id); ?>&idcarga=<?php echo e($d->id); ?>&idsap=<?php echo e($d->nroSap); ?>">
                <button class="btn btn-success">Encuesta</button>
              </a>
            <?php endif; ?>                    
          <?php endif; ?>
          <?php endif; ?>

          <?php if($d->semestre == 6): ?>
              <?php if($d->realizado == 0): ?>
              <button class="bbtn btn-primary"  onclick="cargaExamen(<?php echo e($d->id); ?>, '<?php echo e($d->primerNombre); ?>','<?php echo e($d->primerApellido); ?>'  )">Exam</button>                    
            <?php endif; ?>
            <?php if($d->realizadoco == 0): ?>
              <button class="btn btn-dark" onclick="cargaCO(<?php echo e($d->id); ?>)">Examen Base</button>                    
            <?php endif; ?>
            <?php if($d->agentes_id == 2 || $d->agentes_id == 3 || $d->agentes_id == 6 || $d->agentes_id == 7 || $d->agentes_id == 5 || $d->agentes_id == 4 || $d->agentes_id == 18 ): ?>
             
            <?php if($d->encuesta == 0): ?>
            <a href="/encuesta/?idencuesta=<?php echo e($d->agentes_id); ?>&idcarga=<?php echo e($d->id); ?>&idsap=<?php echo e($d->nroSap); ?>">
              <button class="btn btn-success">Encuesta</button>
            </a>
          <?php endif; ?>    
                                 
          <?php endif; ?>
          
          
                               
        <?php endif; ?>

          
      
          
       </td>
        
     </tr>
     <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      

    </tbody>
</table>






<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\dev\sys-satep\satep\resources\views/prueba/lista.blade.php ENDPATH**/ ?>