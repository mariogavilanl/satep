<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Agente extends Model
{
    //
}
