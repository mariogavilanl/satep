<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Agentes extends Model
{
    //
}
