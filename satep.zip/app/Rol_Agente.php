<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Rol_Agente extends Model
{
    //
}
