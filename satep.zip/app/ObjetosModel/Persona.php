<?php

namespace App\ObjectsModels;

class Persona {
    public function saludo (){
        echo 'Hola';
    }
}
