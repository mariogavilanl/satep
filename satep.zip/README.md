<p align="center">
    <img src="https://ww3.achs.cl/portal/centro-de-noticias/PublishingImages/galerias/achs-3039/codelco.png" width="400">
</p>


## Acerca de SysSatep

Sistema hecho por Diego Echeverria:

